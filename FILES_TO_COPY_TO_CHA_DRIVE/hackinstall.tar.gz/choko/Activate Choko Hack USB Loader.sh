#! /bin/sh
# USB Joystick Mode
# For Choko Hack 12.2.0+

mkdir -p /tmp/CHA_BOOT
BOOTDISK=$(cat /proc/cmdline); BOOTDISK=${BOOTDISK#*'root=/dev/'}; BOOTDISK=${BOOTDISK%'p2 '*}
mount /dev/${BOOTDISK}p1 /tmp/CHA_BOOT

WASOK=0
FNAME=${0##*/}
if [ "$FNAME" = "Activate Choko Hack USB Loader.sh" ]
then
  # CHA is using 1.7 sun8i-h3-orangepi-pc.dtb
  cp /.choko/CHA-1.6-sun8i-h3-orangepi-pc.dtb /tmp/CHA_BOOT/sun8i-h3-orangepi-pc.dtb; WASOK=$?
  if [ $WASOK -eq 0 ]
  then
    mv "/.choko/Activate Choko Hack USB Loader.sh" "/.choko/Restore USB Joystick Mode.sh"; WASOK=$?
  fi
  if [ $WASOK -eq 0 ]
  then
    mv "/.choko/Activate Choko Hack USB Loader.nfo" "/.choko/Restore USB Joystick Mode.nfo"; WASOK=$?
  fi
  if [ $WASOK -eq 0 ]
  then
    echo "Restore USB Joystick Mode" > "/.choko/Restore USB Joystick Mode.nfo"
  fi
  [ $WASOK -eq 0 ] &&  echo -e "\nRebooting with USB Loader support..."
else
  # CHA is using 1.6 sun8i-h3-orangepi-pc.dtb
  cp /.choko/CHA-1.7-sun8i-h3-orangepi-pc.dtb /tmp/CHA_BOOT/sun8i-h3-orangepi-pc.dtb; WASOK=$?
  if [ $WASOK -eq 0 ]
  then
    mv "/.choko/Restore USB Joystick Mode.sh" "/.choko/Activate Choko Hack USB Loader.sh"; WASOK=$?
  fi
  if [ $WASOK -eq 0 ]
  then
    mv "/.choko/Restore USB Joystick Mode.nfo" "/.choko/Activate Choko Hack USB Loader.nfo"; WASOK=$?
  fi
  if [ $WASOK -eq 0 ]
  then
    echo "Activate Choko Hack USB Loader" > "/.choko/Activate Choko Hack USB Loader.nfo"
  fi
  [ $WASOK -eq 0 ] &&  echo -e "\nRebooting with USB Joysticks Mode support..."
fi

umount /tmp/CHA_BOOT 2>/dev/null
[ $WASOK -eq 0 ] || echo -e "\n\e[1;31mThere was some error.\e[m"

sleep 5
# Call for safe unmount and reboot
exit 200
