#! /bin/sh
# /.choko/games1S.sh to load usb_exec.sh from USB
# For Choko Hack 11.0.0+

# Simple string compare, since until 10.0.0 CHOKOVERSION wasn't set
# Future versions need to keep this in mind
if [ "$CHOKOVERSION" \< "11.0.0" ]
then
  echo -e "\nYou are running an outdated version of Choko Hack.\nYou need v11.0.0 or later.\n";
  COUNTDOWN=5
  while [ $COUNTDOWN -ge 0 ]
  do
    echo -ne "\rResuming in $COUNTDOWN seconds... "
    COUNTDOWN=$((COUNTDOWN - 1))
    sleep 1
  done
  exit 1
fi
RUNNINGFROM="$(dirname "$(readlink -f "$0")")"
EXITREQUEST=0

if [ $(find /mnt -mindepth 2 -maxdepth 2 -name usb_exec.sh -type f -print 2> /dev/null | wc -l) -eq 1 ]
then
  FNAME="$(find /mnt -mindepth 2 -maxdepth 2 -name usb_exec.sh -type f -print0 2> /dev/null)"
  cd "${FNAME%/usb_exec.sh}"
  # Convert Windows EOL to Linux EOL
  sed -i 's/^M$//g' "$FNAME"
  "$FNAME" start
  EXITREQUEST=$?
  cd /etc/init.d
  [ $EXITREQUEST -eq 200 ] && /etc/init.d/S11chokopoweroff rebootnow
  [ $EXITREQUEST -eq 201 ] && /etc/init.d/S11chokopoweroff poweroffnow
else
  # Variables to store buttons pressed
  CHA1I="0"
  CHA1A="0"
  CHA1B="0"
  CHA1C="0"
  CHA1D="0"
  CHA1E="0"
  CHA1F="0"
  CHA2A="0"
  CHA2B="0"
  CHA2C="0"
  CHA2D="0"
  CHA2E="0"
  CHA2F="0"

  # Variables to store menu options
  GAMES1I="Capcom Games - Official List"
  # GAMES1S is reserved for Loading Choko Hack from USB or Install Games in CHA
  GAMES1A=""
  GAMES1B=""
  GAMES1C=""
  GAMES1D=""
  GAMES1E=""
  GAMES1F=""
  GAMES2A=""
  GAMES2B=""
  GAMES2C=""
  GAMES2D=""
  GAMES2E=""
  GAMES2F=""

  # Check screen size and display menu background
  SCREENSIZE=$(fbset | sed '2q;d'); SCREENSIZE=${SCREENSIZE#*'"'}; SCREENSIZE=${SCREENSIZE%'-'*}
  cat "$RUNNINGFROM/menu-$SCREENSIZE.rgba" > /dev/fb0

  COLUMNS=`stty -F /dev/tty0 size | cut '-d ' -f2`
  ROWS=`stty -F /dev/tty0 size | cut '-d ' -f1`

  MORELISTS="N"
  DEFAULTOPTION=""

  # Get options to display in menu
  while read FNAME; do
    FIRSTFREE="N"
    for M in "1" "2"
    do
      for N in "A" "B" "C" "D" "E" "F"
      do
        if [ "$FIRSTFREE" = "N" ] && [ -z "$(eval "echo \"\$GAMES$M$N\"")" ]
        then
          FNAME="${FNAME%/usb_exec.sh}"; FNAME="${FNAME#/mnt/}"
          eval "GAMES$M$N=\"\$FNAME\""
          MORELISTS="Y"
          FIRSTFREE="Y"
          [ -z "$DEFAULTOPTION" ] && DEFAULTOPTION="$M$N"
        fi
      done
    done
  done <<EOF
  $(find /mnt -mindepth 2 -maxdepth 2 -name usb_exec.sh -type f -print 2> /dev/null | sort -f)
EOF
  [ -z "$DEFAULTOPTION" ] && DEFAULTOPTION="1I"

  # Add 10 to string length for default choice indicator
  eval "DESCLENGTH=\$((\${#GAMES$DEFAULTOPTION} + 10))"

  # Check strings lenght
  for M in "1" "2"
  do
    for N in "A" "B" "C" "D" "E" "F"
    do
      [ $(eval "echo \"\${#GAMES$M$N} -gt $DESCLENGTH\"") ] && eval "DESCLENGTH=\${#GAMES$M$N}"
    done
  done
  [ ${#GAMES1I} -gt $DESCLENGTH ] && DESCLENGTH=${#GAMES1I}

  # Add space for buttons labels in menu list + border space
  MENUFIX=14

  # Position of top left corner of menu
  MENUTOPROW=$(($ROWS / 2 + 1))
  MENULEFTCOLUMN=$(( ($COLUMNS - $MENUFIX - $DESCLENGTH ) / 2 ))

  TopLeftCorner='\e[12mI'
  TopRightCorner=';\e[10m'
  HorizontalBar='M'
  VerticalBar='\e[12m:\e[10m'
  BottomLeftCorner='\e[12mH'
  BottomRighCorner='<\e[10m'

  BorderColor='\e[1;94m'
  ButtonColor='\e[1;37m'
  OptionColor='\e[1;93m'
  CountdownColor='\e[1;95m'

  # Start drawing the menu
  # Top line + border space
  echo -ne "\e[${MENUTOPROW};${MENULEFTCOLUMN}H$BorderColor$TopLeftCorner"
  i=$(($DESCLENGTH + $MENUFIX))
  while [ $i -gt 0 ]
  do
    echo -ne "$HorizontalBar"
    i=$(($i - 1))
  done
  echo -ne "$TopRightCorner\n\e[${MENULEFTCOLUMN}G$VerticalBar$(printf "%-$(($DESCLENGTH + $MENUFIX))s" " ")$VerticalBar\n"

  # Games lists
  for M in "1" "2"
  do
    for N in "A" "B" "C" "D" "E" "F"
    do
      if [ -n "$(eval "echo \"\$GAMES$M$N\"")" ]
      then
        if [ "$M$N" = "$DEFAULTOPTION" ]
        then
          eval "DESCDEFAULT=\$(printf \"%-${DESCLENGTH}s\" \"\$GAMES$M$N\")"
          DESCDEFAULT="${DESCDEFAULT/          / \\e[1;95m(default)}"
          echo -ne "\e[${MENULEFTCOLUMN}G$VerticalBar  $ButtonColor[ P$M $N ]$OptionColor  $DESCDEFAULT  $BorderColor$VerticalBar\n"
        else
          eval "echo -ne \"\e[${MENULEFTCOLUMN}G$VerticalBar  $ButtonColor[ P$M $N ]$OptionColor  \$(printf \"%-${DESCLENGTH}s\" \"\$GAMES$M$N\")  $BorderColor$VerticalBar\n\""
        fi
      fi
    done
  done
  [ "$MORELISTS" = "Y" ] && echo -ne "\e[${MENULEFTCOLUMN}G$VerticalBar$(printf "%-$(($DESCLENGTH + $MENUFIX))s" " ")$VerticalBar\n"

  # Special menu options
  echo -ne "\e[${MENULEFTCOLUMN}G$VerticalBar  $ButtonColor[ P1 I ]$OptionColor  $(printf "%-${DESCLENGTH}s" "$GAMES1I")  $BorderColor$VerticalBar\n"

  # Border space + bottom line
  echo -ne "\e[${MENULEFTCOLUMN}G$VerticalBar$(printf "%-$(($DESCLENGTH + $MENUFIX))s" " ")$VerticalBar\n\e[${MENULEFTCOLUMN}G$BottomLeftCorner"
  i=$(($DESCLENGTH + $MENUFIX - 8))
  while [ $i -gt 0 ]
  do
    echo -ne "$HorizontalBar"
    i=$(($i - 1))
  done
  echo -ne "\e[10mv$CHOKOVERSION\e[12m$HorizontalBar$BottomRighCorner"

  # Wait for selection and read buttons
  COUNTDOWN=20
  COUNTDOWNX=$(($COLUMNS / 2))
  while [ "$CHA1I$CHA1A$CHA1B$CHA1C$CHA1D$CHA1E$CHA1F$CHA2A$CHA2B$CHA2C$CHA2D$CHA2E$CHA2F" = "0000000000000" ] && [ $COUNTDOWN -ge 0 ]
  do
    # Always show 2 digits in COUNTDOWN
    [ ${#COUNTDOWN} -gt 1 ] && echo -ne "\e[${COUNTDOWNX}G$CountdownColor${COUNTDOWN}" || echo -ne "\e[${COUNTDOWNX}G${CountdownColor}0${COUNTDOWN}"
    COUNTDOWN=$(($COUNTDOWN - 1))
    sleep 1
    if [ -n "$GAMES1I" ]
    then
      /usr/sbin/evtest --query /dev/input/event2 EV_KEY BTN_BASE2
      CHA1I=$?
    fi
    if [ -n "$GAMES1A" ]
    then
      /usr/sbin/evtest --query /dev/input/event2 EV_KEY BTN_TOP
      CHA1A=$?
    fi
    if [ -n "$GAMES1B" ]
    then
      /usr/sbin/evtest --query /dev/input/event2 EV_KEY BTN_TOP2
      CHA1B=$?
    fi
    if [ -n "$GAMES1C" ]
    then
      /usr/sbin/evtest --query /dev/input/event2 EV_KEY BTN_PINKIE
      CHA1C=$?
    fi
    if [ -n "$GAMES1D" ]
    then
      /usr/sbin/evtest --query /dev/input/event2 EV_KEY BTN_TRIGGER
      CHA1D=$?
    fi
    if [ -n "$GAMES1E" ]
    then
      /usr/sbin/evtest --query /dev/input/event2 EV_KEY BTN_THUMB
      CHA1E=$?
    fi
    if [ -n "$GAMES1F" ]
    then
      /usr/sbin/evtest --query /dev/input/event2 EV_KEY BTN_THUMB2
      CHA1F=$?
    fi
    if [ -n "$GAMES2A" ]
    then
      /usr/sbin/evtest --query /dev/input/event3 EV_KEY BTN_TOP
      CHA2A=$?
    fi
    if [ -n "$GAMES2B" ]
    then
      /usr/sbin/evtest --query /dev/input/event3 EV_KEY BTN_TOP2
      CHA2B=$?
    fi
    if [ -n "$GAMES2C" ]
    then
      /usr/sbin/evtest --query /dev/input/event3 EV_KEY BTN_PINKIE
      CHA2C=$?
    fi
    if [ -n "$GAMES2D" ]
    then
      /usr/sbin/evtest --query /dev/input/event3 EV_KEY BTN_TRIGGER
      CHA2D=$?
    fi
    if [ -n "$GAMES2E" ]
    then
      /usr/sbin/evtest --query /dev/input/event3 EV_KEY BTN_THUMB
      CHA2E=$?
    fi
    if [ -n "$GAMES2F" ]
    then
      /usr/sbin/evtest --query /dev/input/event3 EV_KEY BTN_THUMB2
      CHA2F=$?
    fi
  done

  # Put text cursor in top left corner of screen and clear the screen leaving Choko
  echo -ne "\e[1;1H\e[0m"
  clear
  cat "$RUNNINGFROM/choko-$SCREENSIZE.rgba" > /dev/fb0
  # Load selected option
  case "$CHA1I$CHA1A$CHA1B$CHA1C$CHA1D$CHA1E$CHA1F$CHA2A$CHA2B$CHA2C$CHA2D$CHA2E$CHA2F" in
    10000000000000)
      echo "Selected: $GAMES1I"
    ;;
    01000000000000)
      echo "Selected: $GAMES1A"
      sed -i 's/^M$//g' "/mnt/$GAMES1A/usb_exec.sh"
      cd "/mnt/$GAMES1A"
      "/mnt/$GAMES1A/usb_exec.sh" start
      EXITREQUEST=$?
    ;;
    00100000000000)
      echo "Selected: $GAMES1B"
      sed -i 's/^M$//g' "/mnt/$GAMES1B/usb_exec.sh"
      cd "/mnt/$GAMES1B"
      "/mnt/$GAMES1B/usb_exec.sh" start
      EXITREQUEST=$?
    ;;
    00010000000000)
      echo "Selected: $GAMES1C"
      sed -i 's/^M$//g' "/mnt/$GAMES1C/usb_exec.sh"
      cd "/mnt/$GAMES1C"
      "/mnt/$GAMES1C/usb_exec.sh" start
      EXITREQUEST=$?
    ;;
    00001000000000)
      echo "Selected: $GAMES1D"
      sed -i 's/^M$//g' "/mnt/$GAMES1D/usb_exec.sh"
      cd "/mnt/$GAMES1D"
      "/mnt/$GAMES1D/usb_exec.sh" start
      EXITREQUEST=$?
    ;;
    00000100000000)
      echo "Selected: $GAMES1E"
      sed -i 's/^M$//g' "/mnt/$GAMES1E/usb_exec.sh"
      cd "/mnt/$GAMES1E"
      "/mnt/$GAMES1E/usb_exec.sh" start
      EXITREQUEST=$?
    ;;
    00000010000000)
      echo "Selected: $GAMES1F"
      sed -i 's/^M$//g' "/mnt/$GAMES1F/usb_exec.sh"
      cd "/mnt/$GAMES1F"
      "/mnt/$GAMES1F/usb_exec.sh" start
      EXITREQUEST=$?
    ;;
    00000001000000)
      echo "Selected: $GAMES2A"
      sed -i 's/^M$//g' "/mnt/$GAMES2A/usb_exec.sh"
      cd "/mnt/$GAMES2A"
      "/mnt/$GAMES2A/usb_exec.sh" start
      EXITREQUEST=$?
    ;;
    00000000100000)
      echo "Selected: $GAMES2B"
      sed -i 's/^M$//g' "/mnt/$GAMES2B/usb_exec.sh"
      cd "/mnt/$GAMES2B"
      "/mnt/$GAMES2B/usb_exec.sh" start
      EXITREQUEST=$?
    ;;
    00000000010000)
      echo "Selected: $GAMES2C"
      sed -i 's/^M$//g' "/mnt/$GAMES2C/usb_exec.sh"
      cd "/mnt/$GAMES2C"
      "/mnt/$GAMES2C/usb_exec.sh" start
      EXITREQUEST=$?
    ;;
    00000000001000)
      echo "Selected: $GAMES2D"
      sed -i 's/^M$//g' "/mnt/$GAMES2D/usb_exec.sh"
      cd "/mnt/$GAMES2D"
      "/mnt/$GAMES2D/usb_exec.sh" start
      EXITREQUEST=$?
    ;;
    00000000000100)
      echo "Selected: $GAMES2E"
      sed -i 's/^M$//g' "/mnt/$GAMES2E/usb_exec.sh"
      cd "/mnt/$GAMES2E"
      "/mnt/$GAMES2E/usb_exec.sh" start
      EXITREQUEST=$?
    ;;
    00000000000010)
      echo "Selected: $GAMES2F"
      sed -i 's/^M$//g' "/mnt/$GAMES2F/usb_exec.sh"
      cd "/mnt/$GAMES2F"
      "/mnt/$GAMES2F/usb_exec.sh" start
      EXITREQUEST=$?
    ;;
    *)
      eval "echo \"Selected: \$GAMES$DEFAULTOPTION\""
      # Convert Windows EOL to Linux EOL
      sed -i 's/^M$//g' "$(eval "echo \"/mnt/\$GAMES$DEFAULTOPTION/usb_exec.sh\"")"
      eval "cd \"/mnt/\$GAMES$DEFAULTOPTION\""
      eval "\"/mnt/\$GAMES$DEFAULTOPTION/usb_exec.sh\" start"
      EXITREQUEST=$?
    ;;
  esac
fi
exit $EXITREQUEST
